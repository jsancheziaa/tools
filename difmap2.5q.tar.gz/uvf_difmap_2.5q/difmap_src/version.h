printf("Caltech difference mapping program - version 2.5q (3 Dec 2022)\n");

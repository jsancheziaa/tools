Model *mapclean(Observation *ob, MapBeam *mb, Mapwin *mw, int maxcmp,
		float cutoff, float gain, int docomp);

#ifndef uhdu_h
#define uhdu_h

/* Unknown extension-type HDU descriptor */

typedef struct {
  HDUBase
} Uhdu;

#endif

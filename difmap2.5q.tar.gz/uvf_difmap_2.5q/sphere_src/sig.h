void interrupt_handler(int sig);
void float_exception(int sig);
void sig_init(void);
extern int no_error;
extern int in_run_mode;
